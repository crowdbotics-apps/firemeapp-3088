run_spec(__dirname, ["__ng_interpolation"]);
run_spec(__dirname, ["__ng_interpolation"], { trailingComma: "es5" });
run_spec(__dirname, ["__ng_interpolation"], { trailingComma: "all" });
