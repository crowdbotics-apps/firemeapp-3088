fnString =
  // Comment
  'some' + 'long' + 'string';

var fnString =
  // Comment
  'some' + 'long' + 'string';

var fnString =
  // Comment

  'some' + 'long' + 'string';

var fnString =

  // Comment

  'some' + 'long' + 'string';

var fnString =
  /* comment */
  'some' + 'long' + 'string';

var fnString =
  /**
   * multi-line
   */
  'some' + 'long' + 'string';

var fnString =
  /* inline */ 'some' + 'long' + 'string' + 'some' + 'long' + 'string' + 'some' + 'long' + 'string' + 'some' + 'long' + 'string';

var fnString = // Comment
  // Comment
  'some' + 'long' + 'string';

var fnString = // Comment
  'some' + 'long' + 'string';

let f1 = (
  a =
  //comment
  b
) => {};

let f2 = (
  a = //comment
  b
) => {};

let f3 = (
  a =
  b //comment
) => {};
