run_spec(__dirname, ["scss"]);
run_spec(__dirname, ["scss"], { trailingComma: "es5" });
