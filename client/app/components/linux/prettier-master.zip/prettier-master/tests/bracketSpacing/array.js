const arr1 = [1,2,3,4];
const arr2 = [1, 2, 3, 4];
