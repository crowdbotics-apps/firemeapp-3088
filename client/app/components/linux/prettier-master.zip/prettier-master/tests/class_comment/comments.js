class A // comment 1
  // comment 2
  extends B {}

class A1 extends B // comment1
// comment2
// comment3
{}

class A2 /* a */ extends B {}
class A3 extends B /* a */ {}
class A4 extends /* a */ B {}

(class A5 // comment 1
  // comment 2
  extends B {});

(class A6 extends B // comment1
// comment2
// comment3
{});

(class A7 /* a */ extends B {});
(class A8 extends B /* a */ {});
(class A9 extends /* a */ B {});

class x {
  focus() // do nothing
  {
    // do nothing
  }
}

class X {
  TEMPLATE =
    // tab index is needed so we can focus, which is needed for keyboard events
    '<div class="ag-large-text" tabindex="0">' +
    '<div class="ag-large-textarea"></div>' +
    '</div>';
}

export class SnapshotLogger {
  constructor(
    retentionPeriod: number = 5 * 60 * 1000, // retain past five minutes
    snapshotInterval: number = 30 * 1000, // snapshot no more than every 30s
  ) {
  }
}
