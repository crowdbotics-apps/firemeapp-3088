<div
  // comment
>
  {foo}
</div>;

<div
  // comment
  attr="foo"
>
  {foo}
</div>;

<div
  attr="foo" // comment
>
  {foo}
</div>;

<div
  attr="foo"
  // comment
>
  {foo}
</div>;

<br // comment
/>;
