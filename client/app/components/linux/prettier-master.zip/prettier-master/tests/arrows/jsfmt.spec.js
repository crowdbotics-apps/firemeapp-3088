run_spec(__dirname, ["babel", "typescript"], { arrowParens: "avoid" });
run_spec(__dirname, ["babel", "typescript"], { arrowParens: "always" });
