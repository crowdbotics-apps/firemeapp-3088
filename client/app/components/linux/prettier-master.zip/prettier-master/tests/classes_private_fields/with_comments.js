class A {
  #foobar =
    // comment to break
    1 +
    // comment to break again
    2;
}
