class A1 {
  // comment
}

class A2 { // comment
}

class A3 {
}

class A4 {
  m() {}
}
