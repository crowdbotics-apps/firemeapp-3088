run_spec(__dirname, ["flow", "typescript"]);
