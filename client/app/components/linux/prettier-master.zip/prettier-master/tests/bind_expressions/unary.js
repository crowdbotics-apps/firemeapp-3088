!x::y;
!(x::y /* foo */);
!(/* foo */ x::y);
!(
  /* foo */
  x::y
);
!(
  x::y
  /* foo */
);
!(
  x::y // foo
);
