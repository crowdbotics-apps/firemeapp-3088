run_spec(__dirname, ["babel"]);
run_spec(__dirname, ["babel"], { semi: false });
