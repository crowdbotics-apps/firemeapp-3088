const FLAG_A = 1 << 0;
const FLAG_B = 1 << 1;
const FLAG_C = 1 << 2;

const all = FLAG_A | FLAG_B | FLAG_C;
