a ** b ** c;
(a ** b) ** c;
a.b ** c;
(-a) ** b;
a ** -b;
-(a**b);
(a * b) ** c;
a ** (b * c);
(a % b) ** c;
