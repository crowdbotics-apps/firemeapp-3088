for ((i = 0), (len = arr.length); i < len; i++) {
  console.log(arr[i])
}

for (i = 0, len = arr.length; i < len; i++) {
  console.log(arr[i])
}
