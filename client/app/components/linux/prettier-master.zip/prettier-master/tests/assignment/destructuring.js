let {
  bottom: offsetBottom,
  left: offsetLeft,
  right: offsetRight,
  top: offsetTop,
} = getPressRectOffset == null ? DEFAULT_PRESS_RECT : getPressRectOffset();

const { accessibilityModule: FooAccessibilityModule, accessibilityModule: FooAccessibilityModule2, accessibilityModule: FooAccessibilityModule3, accessibilityModule: FooAccessibilityModule4,
      } = foo || {};

({ prop: toAssign = "default" } = { prop: "propval" });
