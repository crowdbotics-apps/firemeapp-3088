run_spec(__dirname, ["css"]);
run_spec(__dirname, ["scss"], { trailingComma: "es5" });
