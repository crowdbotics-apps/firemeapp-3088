run_spec(__dirname, ["css"]);
run_spec(__dirname, ["css"], { singleQuote: true });
