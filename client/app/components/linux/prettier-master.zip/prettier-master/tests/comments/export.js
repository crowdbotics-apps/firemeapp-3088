export //comment
{}

export /* comment */ {};

const foo = ''
export {
  foo // comment
}

const bar = ''
export {
  // comment
  bar
}

const fooo = ''
const barr = ''
export {
  fooo, // comment
  barr, // comment
}
