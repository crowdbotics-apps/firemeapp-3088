`
${a // comment
}

${b /* comment */}

${/* comment */ c /* comment */}

${// comment
d //comment
};
`
