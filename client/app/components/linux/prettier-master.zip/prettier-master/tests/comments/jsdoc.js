/** @type {any} */
const x = (
    <div>
        <div />
    </div>
);

/**
 * @type {object}
 */
() => (
    <div>
        sajdfpoiasdjfpoiasdjfpoiasdjfpoiadsjfpaoisdjfapsdiofjapioisadfaskfaspiofjp
    </div>
);

/**
 * @type {object}
 */
function HelloWorld() {
    return (
        <div>
           <span>Test</span>
        </div>
    );
}