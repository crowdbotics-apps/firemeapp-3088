function f() {
  a
  /* eslint-disable */
}

function f() {
  a

  /* eslint-disable */
}

function name() {
  // comment1
  func1()

  // comment2
  func2()

  // comment3 why func3 commented
  // func3()
}
