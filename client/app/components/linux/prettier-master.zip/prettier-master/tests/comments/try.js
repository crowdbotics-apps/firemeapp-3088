// Comment 1
try { // Comment 2
  // Comment 3
}
// Comment 4
catch(e) { // Comment 5
  // Comment 6
}
// Comment 7
finally { // Comment 8
  // Comment 9
}
// Comment 10
