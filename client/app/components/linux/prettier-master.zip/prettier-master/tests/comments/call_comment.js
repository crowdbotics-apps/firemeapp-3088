render( // Warm any cache
  <ChildUpdates renderAnchor={true} anchorClassOn={true} />,
  container
);

React.render( // Warm any cache
  <ChildUpdates renderAnchor={true} anchorClassOn={true} />,
  container
);

render?.( // Warm any cache
  <ChildUpdates renderAnchor={true} anchorClassOn={true} />,
  container
);
