import(/* Hello */ 'something')

import('something' /* Hello */)

import(/* Hello */ 'something' /* Hello */)

import('something' /* Hello */ + 'else')

import(
  /* Hello */
  'something'
  /* Hello */
)

wrap(
  import(/* Hello */
    'something'
  )
)
