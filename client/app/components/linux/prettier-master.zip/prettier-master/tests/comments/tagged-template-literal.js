foo``; // comment

foo // comment
``;

foo // comment
`
`;

foo /* comment */`
`;

foo /* comment */
`
`;
