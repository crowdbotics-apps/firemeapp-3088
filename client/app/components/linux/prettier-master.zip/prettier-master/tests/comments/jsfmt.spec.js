run_spec(__dirname, ["flow", "babel", "typescript"]);
run_spec(__dirname, ["flow", "babel", "typescript"], { semi: false });
