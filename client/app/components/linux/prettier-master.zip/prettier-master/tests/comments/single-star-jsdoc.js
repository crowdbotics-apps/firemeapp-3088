/*
 * Looking good!
 */

if(true) {
    /*
     * Oh no
     */
}

  /** first line
* second line
   * third line */

  /* first line
* second line
   * third line */

  /*! first line
*second line
   *  third line */

/*!
* Extracted from vue codebase
* https://github.com/vuejs/vue/blob/cfd73c2386623341fdbb3ac636c4baf84ea89c2c/src/compiler/parser/html-parser.js
* HTML Parser By John Resig (ejohn.org)
* Modified by Juriy "kangax" Zaytsev
* Original code by Erik Arvidsson, Mozilla Public License
* http://erik.eae.net/simplehtmlparser/simplehtmlparser.js
*/
