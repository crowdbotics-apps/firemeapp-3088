const fn = (/*event, data*/) => doSomething();

const fn2 = (/*event, data*/) => doSomething(anything);
