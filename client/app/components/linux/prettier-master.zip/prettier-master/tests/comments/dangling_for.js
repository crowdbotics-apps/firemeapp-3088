for // comment
(;;);

for /* comment */(;;);
