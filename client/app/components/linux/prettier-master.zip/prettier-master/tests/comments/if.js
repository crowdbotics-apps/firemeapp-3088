if (1)
// comment
{
  false
}
// comment
else if (2)
  true
// multi
// ple
// lines
else if (3)
  // existing comment
  true
// okay?
else if (4) {
  // empty with existing comment
}
// comment
else {
}

if (5) // comment
true

if (6) // comment
{true}
else if (7) // comment
true
else // comment
{true}

if (8) // comment
// comment
{true}
else if (9) // comment
// comment
true
else // comment
// comment
{true}

if (10) /* comment */ // comment
{true}
else if (11) /* comment */
true
else if (12) // comment /* comment */ // comment
true
else if (13) /* comment */ /* comment */ // comment
true
else /* comment */
{true}

if (14) // comment
/* comment */
// comment
{true}
else if (15) // comment
/* comment */
/* comment */ // comment
true
