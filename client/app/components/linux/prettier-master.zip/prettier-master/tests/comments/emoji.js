/* #2091 */

const test = '💖'
// This comment
// should not get collapsed
