this.size = this._origin = this._capacity = 0;
