const testConsole = new TestConsole(
  config.useStderr ? process.stderr : process.stdout
);
