// no-confusing-arrow
var x = a => 1 ? 2 : 3;
var x = a <= 1 ? 2 : 3;
