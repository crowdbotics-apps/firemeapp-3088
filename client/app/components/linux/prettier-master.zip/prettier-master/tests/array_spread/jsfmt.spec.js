run_spec(__dirname, ["babel", "flow", "typescript"]);
